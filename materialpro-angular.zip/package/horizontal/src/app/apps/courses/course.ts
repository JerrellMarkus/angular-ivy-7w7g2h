// tslint:disable-next-line: class-name
export class course {
    Id = -1;
    courseType = '';
    Time = '';
    courseName = '';
    Update = '';
}
